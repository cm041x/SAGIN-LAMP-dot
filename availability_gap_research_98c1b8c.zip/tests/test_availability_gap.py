import unittest
from dataclasses import replace
from collections import deque
import numpy as np
import torch
from Our_experiment.HCSAC.ENV.UAVenv_DynamicFleet import Status
from Our_experiment.HCSAC.training.dynamic_hcsac_trainer import new_env
from Our_experiment.HCSAC.lamp_method.collector import frozen_flight_actor
from Our_experiment.HCSAC.flight_residual.policy import FlightActor,flight_observe,encode
from Our_experiment.HCSAC.availability_gap.observation import observe,availability_features
from Our_experiment.HCSAC.availability_gap.planner import Policy,PlannerConfig,choose,assignment,estimates

SEEDS={'wind_seed':1180,'terrain_seed':900000,'infra_seed':900000}

class AvailabilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2);cls.cnn=frozen_flight_actor()
    def env(self):return new_env(30,SEEDS)

    def test_fixed_slots_and_masks(self):
        e=self.env();o=observe(e,e._get_obs());self.assertEqual(o.existence_mask.tolist(),[True]*6)
        self.assertEqual(o.flight_mask.tolist(),[True]*4+[False]*2)
        self.assertEqual(len(e.eligible),0)

    def test_inactive_energy_isolated_from_original_active_graph(self):
        e=self.env();u=e.uavs[4];u['status']=Status.CHARGING;u['done']=True;u['energy']=.2*e.initial_energy
        first=flight_observe(e,e._get_obs(),self.cnn);o1=observe(e,e._get_obs())
        u['energy']=.8*e.initial_energy;second=flight_observe(e,e._get_obs(),self.cnn);o2=observe(e,e._get_obs())
        self.assertFalse(np.array_equal(availability_features(o1),availability_features(o2)))
        for variant in ('gcn_flight_residual','lamp_plain_flight_residual'):
            torch.manual_seed(12);model=FlightActor(variant)
            with torch.no_grad():a,_=encode(model.encoder,first,None);b,_=encode(model.encoder,second,None)
            self.assertTrue(torch.equal(a[:4],b[:4]),variant)

    def test_wait_age_sensitive_in_telemetry_but_isolated_in_graph(self):
        e=self.env();e.step_number=10;u=e.uavs[4];u['status']=Status.WAITING;u['done']=True;e.queue=deque([4]);u['waiting_since_step']=8
        first=flight_observe(e,e._get_obs(),self.cnn);o1=observe(e,e._get_obs());u['waiting_since_step']=2
        second=flight_observe(e,e._get_obs(),self.cnn);o2=observe(e,e._get_obs())
        self.assertFalse(np.array_equal(availability_features(o1),availability_features(o2)))
        torch.manual_seed(12);model=FlightActor('gcn_flight_residual')
        with torch.no_grad():a,_=encode(model.encoder,first,None);b,_=encode(model.encoder,second,None)
        self.assertTrue(torch.equal(a[:4],b[:4]))

    def test_no_inactive_edges(self):
        e=self.env();g=e.get_obs_2();self.assertFalse(any(int(x) in (4,5) for x in g.edge_index.flatten()))

    def test_hungarian_and_unique_assignments(self):
        self.assertEqual(assignment(np.array([[1.,9.,9.],[9.,1.,9.]])),[0,1])
        e=self.env();o=observe(e,e._get_obs());a,trace=choose(e,o,self.cnn,Policy.P1,PlannerConfig())
        self.assertEqual(len(trace['targets']),len(set(trace['targets'].values())))
        self.assertTrue(all(0<=a[i]<8 for i in range(6)))
        for i in trace['targets']:
            p=o.positions[i];d=e.directions[a[i]];self.assertLessEqual(max(abs(d[0]),abs(d[1])),1)
            self.assertTrue(0<=p[0]+d[0]<20 and 0<=p[1]+d[1]<20)

    def test_forecast_changes_with_current_energy_not_future(self):
        e=self.env();o=observe(e,e._get_obs());ids=np.flatnonzero(o.flight_mask).tolist();cfg=PlannerConfig()
        a,_,_=estimates(e,o,ids,cfg);energies=list(o.energies);energies[ids[0]]*=.5
        b,_,_=estimates(e,replace(o,energies=tuple(energies)),ids,cfg)
        self.assertLessEqual(b[0],a[0]);e.uavs[ids[0]]['energy']=1
        c,_,_=estimates(e,o,ids,cfg);np.testing.assert_array_equal(a,c)

    def test_charging_recovery_waits_for_full_charge(self):
        e=self.env();u=e.uavs[4];u['status']=Status.CHARGING;u['done']=True;u['energy']=.96*e.initial_energy
        o=observe(e,e._get_obs());_,_,times=estimates(e,o,np.flatnonzero(o.flight_mask).tolist(),PlannerConfig())
        self.assertEqual(times[4],1)
        self.assertGreater(times[4],0.)

    def test_no_global_uncertainty_access(self):
        e=self.env();o=observe(e,e._get_obs());before=choose(e,o,self.cnn,Policy.P2,PlannerConfig())[0]
        e.uncertainty_matrix[:]=0
        after=choose(e,o,self.cnn,Policy.P2,PlannerConfig())[0]
        self.assertEqual(before,after)

if __name__=='__main__':unittest.main()
