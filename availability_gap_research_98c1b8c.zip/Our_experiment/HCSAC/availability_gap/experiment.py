"""Paired fixed-protocol P0/P1/P2 rollouts on the unchanged V1.5 environment."""
import argparse
import csv
import hashlib
import json
import math
import os
import random
import time
import traceback
from pathlib import Path
import numpy as np
import torch
from .observation import observe
from .planner import Policy,PlannerConfig,choose
from Our_experiment.HCSAC.ENV.UAVenv_SAC_Original import PolicyNet_GCN
from Our_experiment.HCSAC.lamp_method.collector import frozen_flight_actor
from Our_experiment.HCSAC.training.dynamic_hcsac_trainer import new_env

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'outputs/availability_gap'
RESULTS=ROOT/'results/availability_gap'
RELEVANT_EVENTS={'standby_to_active','active_to_returning','charging_to_standby','charging_started','returned_to_vehicle','energy_exhausted_before_return'}

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);p=path.with_suffix(path.suffix+'.tmp')
    p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');os.replace(p,path)

def fingerprint():
    files=sorted(p for p in (ROOT/'Our_experiment/HCSAC/availability_gap').glob('*.py') if not p.name.startswith('._'))
    files+=[ROOT/'ENV_CONTRACT.json',ROOT/'SCENARIO_MANIFEST.json']
    return hashlib.sha256(b''.join(p.read_bytes() for p in files)).hexdigest()

def scenarios(stage,manifest):
    if stage=='development':return manifest['development']
    out=[]
    for cls,winds in manifest['confirmation_winds'].items():
        for wind in winds:
            for seed in manifest['confirmation_terrain_infrastructure_seeds']:
                out.append({'wind_class':cls,'wind_seed':wind,'terrain_seed':seed,'infra_seed':seed})
    return out

def energy(env):
    return sum(env.energy_stats[k] for k in ('search_flight_energy_j','return_flight_energy_j','offload_energy_j'))

def rollout(spec,policy,cnn,gcn,config):
    random.seed(spec['terrain_seed']);np.random.seed(spec['terrain_seed']);torch.manual_seed(spec['terrain_seed'])
    env=new_env(500,spec);state=env._get_obs();initial=float(env.uncertainty_matrix.sum())
    # Every method receives the same explicit centralized observation object.
    timeline=[];events=[];pending={};launch_delays=[];requested=np.zeros(5,dtype=int);effective=np.zeros(5,dtype=int)
    threshold={.9:None,.95:None};energy_threshold={.9:None,.95:None};planning_seconds=0.
    forecasts_used=0;chosen_targets=0;inactive_offloads=0;max_charging=0
    for t in range(1,501):
        o=observe(env,state);before=env.uncertainty_matrix.copy();event_start=len(env.events)
        began=time.perf_counter();actions,trace=choose(env,o,cnn,policy,PlannerConfig());planning_seconds+=time.perf_counter()-began
        if len(actions)!=6 or any(not 0<=a<8 for a in actions):raise RuntimeError('Invalid fixed-slot flight action')
        forecasts_used+=int(trace.get('prediction') is not None);chosen_targets+=len(trace.get('targets',{}))
        state,_,done=env.step(actions)
        postflight_events=env.events[event_start:]
        for e in postflight_events:
            if e['event_type']=='standby_to_active':
                uid=int(e['uav_id'])
                if uid in pending:
                    pending[uid]['censored']=True;pending[uid]['reason']='relaunched_before_new_coverage';launch_delays.append(pending.pop(uid))
                pending[uid]={'uav_id':uid,'launch_step':t,'post_charge':env.uavs[uid]['charging_count']>0,'censored':None}
        covered_ids=[];seen=set()
        for i in sorted(env.eligible):
            pos=tuple(env.uavs[i]['position'])
            if before[pos]>0 and pos not in seen:
                covered_ids.append(i);seen.add(pos)
        for i in list(pending):
            if i in covered_ids:
                item=pending.pop(i);item.update(delay_steps=t-item['launch_step'],censored=False,reason='first_new_coverage');launch_delays.append(item)
            elif env.uavs[i]['status'].value!='active':
                item=pending.pop(i);item.update(delay_steps=t-item['launch_step'],censored=True,reason='left_search');launch_delays.append(item)
        graph=env.get_obs_2();ids=sorted(env.eligible);off=[0]*env.N
        if ids:
            if config=='fixed_haps':
                for i in ids:off[i]=2
            elif config=='pretrained_gcn':
                with torch.no_grad():probs=gcn(graph)
                for i in ids:off[i]=int(probs[i].argmax())
            else:raise ValueError(config)
        before_energy=[u['energy'] for u in env.uavs]
        _,off_reward,done_off=env.step_offload(off)
        for i in set(range(env.N))-set(ids):
            if off_reward[i]!=0 or env.uavs[i]['energy']!=before_energy[i]:inactive_offloads+=1
        requested+=np.asarray(env.offload_timeline[-1]['requested']);effective+=np.asarray(env.offload_timeline[-1]['effective'])
        for u in env.uavs:
            if not math.isfinite(u['energy']) or u['energy']<0 or u['energy']>env.initial_energy+1e-7:raise ValueError('Invalid energy')
        counts=env.get_fleet_counts();max_charging=max(max_charging,counts['charging_count'])
        if counts['charging_count']>env.config.charging_capacity:raise RuntimeError('Charger overloaded')
        coverage=1-float(env.uncertainty_matrix.mean());new=float(np.sum(before-env.uncertainty_matrix))
        for q in threshold:
            if threshold[q] is None and coverage>=q:threshold[q]=t;energy_threshold[q]=energy(env)
        event_types=[e['event_type'] for e in env.events[event_start:]]
        events.extend(e for e in env.events[event_start:] if e['event_type'] in RELEVANT_EVENTS)
        timeline.append({'step':t,'coverage':coverage,'new_coverage_cells':new,'search_active_count':counts['search_active_count'],
            'airborne_count':counts['airborne_count'],'queue_length':len(env.queue),'charging_count':counts['charging_count'],
            'active_decisions':len(ids),'new_coverage_uavs':covered_ids,'rotation_event':any(x in ('standby_to_active','active_to_returning') for x in event_types)})
        if done or done_off:break
    for item in pending.values():item.update(delay_steps=len(timeline)-item['launch_step'],censored=True,reason='episode_end');launch_delays.append(item)
    rotations=[x['step'] for x in timeline if x['rotation_event']]
    around=[x for x in timeline if any(abs(x['step']-t)<=10 for t in rotations)]
    normal=[x for x in timeline if not any(abs(x['step']-t)<=10 for t in rotations)]
    def gain_rate(rows):return sum(x['new_coverage_cells'] for x in rows)/max(1,sum(x['active_decisions'] for x in rows))
    def phase(rows):return {'steps':len(rows),'mean_coverage':float(np.mean([x['coverage'] for x in rows])) if rows else None,
                           'gain_per_active_step':gain_rate(rows) if rows else None}
    steps=len(timeline);covers=[x['coverage'] for x in timeline];n_new=initial-float(env.uncertainty_matrix.sum());visits=env.total_visit_count
    post=[x for x in launch_delays if x['post_charge']];complete=[x['delay_steps'] for x in post if not x['censored']]
    waiting_censored=[max(0,env.step_number-u['waiting_since_step']) for u in env.uavs if u['status'].value=='waiting_charge' and u['waiting_since_step'] is not None]
    types=[x['event_type'] for x in events]
    result={'stage':spec['stage'],'wind_class':spec['wind_class'],'wind_seed':spec['wind_seed'],'terrain_seed':spec['terrain_seed'],
        'infra_seed':spec['infra_seed'],'policy':policy.value,'offload_control':config,'steps':steps,'coverage_auc':float(np.mean(covers)),
        'final_coverage':covers[-1],'coverage_gain_cells':n_new,'total_uav_energy_j':energy(env),
        'search_flight_energy_j':env.energy_stats['search_flight_energy_j'],'return_flight_energy_j':env.energy_stats['return_flight_energy_j'],
        'repeated_visit_ratio':(visits-n_new)/max(1,visits),'mean_active':float(np.mean([x['search_active_count'] for x in timeline])),
        'min_active':min(x['search_active_count'] for x in timeline),'max_active':max(x['search_active_count'] for x in timeline),
        'integrated_fleet_deficit':sum(max(0,4-x['search_active_count']) for x in timeline),
        'mean_queue_length':float(np.mean([x['queue_length'] for x in timeline])),
        'mean_waiting_steps_completed':float(np.mean(env.waiting_charge_steps)) if env.waiting_charge_steps else None,
        'waiting_completed_count':len(env.waiting_charge_steps),'waiting_censored_count':len(waiting_censored),
        'post_charge_relaunch_count':len(post),'post_charge_relaunch_completed_count':len(complete),
        'post_charge_relaunch_censored_count':sum(x['censored'] for x in post),
        'mean_post_charge_first_new_delay':float(np.mean(complete)) if complete else None,
        'return_count':types.count('active_to_returning'),'launch_count':types.count('standby_to_active'),
        'charge_complete_count':types.count('charging_to_standby'),'exhaustion_count':types.count('energy_exhausted_before_return'),
        'rotation_window_steps':len(around),'rotation_window_gain_per_active_step':gain_rate(around) if around else None,
        'ordinary_steps':len(normal),'ordinary_gain_per_active_step':gain_rate(normal) if normal else None,
        'early':phase(timeline[:steps//3]),'middle':phase(timeline[steps//3:2*steps//3]),'late':phase(timeline[2*steps//3:]),
        'near_saturation':phase([x for x in timeline if x['coverage']>=.9]),
        'planning_seconds':planning_seconds,'forecasts_used':forecasts_used,'targets_assigned':chosen_targets,
        'inactive_offload_count':inactive_offloads,'max_charging_count':max_charging,
        'requested_offload_counts':requested.tolist(),'effective_offload_counts':effective.tolist()}
    for q in (.9,.95):
        result[f'time_to_{int(q*100)}_steps']=threshold[q] if threshold[q] is not None else steps
        result[f'time_to_{int(q*100)}_observed']=threshold[q] is not None
        result[f'energy_to_{int(q*100)}_j']=energy_threshold[q]
    return {'metrics':result,'timeline':timeline,'events':events,'launch_delays':launch_delays,'waiting_censored_steps':waiting_censored}

def csv_write(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:return
    keys=list(rows[0]);tmp=path.with_suffix('.tmp')
    with tmp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for row in rows:w.writerow({k:json.dumps(v,separators=(',',':')) if isinstance(v,(dict,list)) else v for k,v in row.items()})
    os.replace(tmp,path)

def execute(stage,control,resume=True):
    manifest=json.loads((ROOT/'SCENARIO_MANIFEST.json').read_text());contract=json.loads((ROOT/'ENV_CONTRACT.json').read_text())
    expected=contract['input_sha256'];checks={'cnn':'Our_experiment/HCSAC/data/sac_model_fly.pt','gcn':'Our_experiment/HCSAC/data/sac_model_offload.pt',
        'wind':'Our_experiment/HCSAC/wind.json','catalog':'Our_experiment/HCSAC/Our_experiment/HCSAC/data/wind_seed_classes_5000.json',
        'ga':'Our_experiment/GA/data/ga_best_deployment_random10_w23_g10_i999999_pool0_200.json',
        'environment_v15':'Our_experiment/HCSAC/ENV/UAVenv_DynamicFleetV15.py','environment_v1':'Our_experiment/HCSAC/ENV/UAVenv_DynamicFleetV1.py'}
    for name,path in checks.items():
        if digest(ROOT/path)!=expected[name]:raise ValueError('Input hash mismatch: '+name)
    fp=fingerprint();cnn=frozen_flight_actor();gcn=PolicyNet_GCN(6,128,5).eval()
    gcn.load_state_dict(torch.load(ROOT/checks['gcn'],map_location='cpu',weights_only=True)['actor_state_dict'])
    cases=scenarios(stage,manifest);records=[];failures=[]
    for scenario in cases:
        scenario={**scenario,'stage':stage}
        for policy in Policy:
            run_id=f"{stage}_{control}_{policy.name}_w{scenario['wind_seed']}_s{scenario['terrain_seed']}"
            dest=OUT/stage/control/(run_id+'.json');identity={'code_fingerprint':fp,'scenario':scenario,'policy':policy.value,'offload_control':control}
            try:
                if dest.exists():
                    if not resume:raise FileExistsError(dest)
                    data=json.loads(dest.read_text())
                    if data['identity']!=identity:raise ValueError('Cannot reuse a run with a different frozen protocol')
                else:
                    data=rollout(scenario,policy,cnn,gcn,control);data.update(run_id=run_id,identity=identity);write(dest,data)
                records.append({'run_id':run_id,**data['metrics']})
                print('complete',run_id,'auc',round(data['metrics']['coverage_auc'],4),flush=True)
            except Exception:
                failures.append({'run_id':run_id,'traceback':traceback.format_exc()})
                OUT.mkdir(parents=True,exist_ok=True)
                with (OUT/'failures.jsonl').open('a') as f:f.write(json.dumps(failures[-1])+'\n')
                print('failed',run_id,flush=True)
    csv_write(RESULTS/f'{stage}_{control}_per_run.csv',records)
    write(OUT/f'{stage}_{control}_manifest.json',{'expected':len(cases)*3,'completed':len(records),'failed':len(failures),'code_fingerprint':fp,'run_ids':[r['run_id'] for r in records]})
    if failures:raise RuntimeError(f'{len(failures)} runs failed; see failures.jsonl')
    return records

def main():
    torch.set_num_threads(2)
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('development','confirmation','offload-validation'),required=True)
    p.add_argument('--resume',action='store_true');a=p.parse_args()
    stage='confirmation' if a.stage=='offload-validation' else a.stage
    execute(stage,'pretrained_gcn' if a.stage=='offload-validation' else 'fixed_haps',a.resume)

if __name__=='__main__':main()
