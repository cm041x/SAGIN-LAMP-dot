"""Explicit centralized telemetry; no added physical graph or hidden oracle map."""
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class CurrentObservation:
    local: np.ndarray
    known_uncertainty: np.ndarray
    flight_mask: np.ndarray
    existence_mask: np.ndarray
    positions: tuple
    statuses: tuple
    energies: tuple
    queue: tuple
    waiting_steps: tuple
    step: int
    vehicle: tuple
    initial_energy: float
    step_seconds: float
    charge_j_per_step: float
    launch_ratio: float
    return_ratio: float
    return_margin: float

def observe(env,local):
    # This map contains only cells exposed by current active 15x15 CNN views.
    # -1 from occupancy or map padding is unknown, never interpreted as covered.
    mask=env.get_search_active_mask();known=np.full((env.Lx,env.Ly),np.nan)
    positions=tuple(tuple(int(v) for v in u['position']) for u in env.uavs)
    for i in np.flatnonzero(mask):
        x,y=positions[i]
        for a in range(15):
            gx=x+a-7
            if not 0<=gx<env.Lx:continue
            for b in range(15):
                gy=y+b-7
                if 0<=gy<env.Ly and local[i,0,a,b]>=0:
                    known[gx,gy]=float(local[i,0,a,b])
    return CurrentObservation(np.array(local,copy=True),known,mask.copy(),np.ones(env.N,dtype=bool),positions,
        tuple(u['status'].value for u in env.uavs),tuple(float(u['energy']) for u in env.uavs),tuple(env.queue),
        tuple(0 if u.get('waiting_since_step') is None else max(0,env.step_number-u['waiting_since_step']) for u in env.uavs),
        int(env.step_number),tuple(env.config.charging_vehicle_position),float(env.initial_energy),float(env.T),
        float(env.config.charging_power_w*env.config.charging_efficiency*env.T),
        float(env.config.minimum_launch_energy_ratio),float(env.config.return_trigger_ratio),float(env.config.return_energy_margin_ratio))

def availability_features(obs):
    """Direct current telemetry, not a new communication edge or future label."""
    statuses=('standby','active','returning','waiting_charge','charging')
    return np.array([[*(float(s==t) for t in statuses),e/obs.initial_energy,
                      p[0]/19,p[1]/19,float(i in obs.queue),obs.waiting_steps[i]/500.]
                     for i,(s,e,p) in enumerate(zip(obs.statuses,obs.energies,obs.positions))],dtype=float)
