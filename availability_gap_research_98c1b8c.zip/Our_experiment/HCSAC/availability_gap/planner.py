"""P1/P2 common deterministic assignment and eight-neighbor planner."""
from dataclasses import dataclass
from enum import Enum
import math
import numpy as np
import torch
from .observation import availability_features

class Policy(str,Enum):
    P0='p0_frozen_cnn'
    P1='p1_current_coordination'
    P2='p2_predicted_availability'

@dataclass(frozen=True)
class PlannerConfig:
    horizon: int=30
    max_candidates: int=96
    forecast_weight: float=4.0
    spatial_scale: float=5.0
    energy_weight: float=.10

def cheb(a,b):return max(abs(int(a[0])-int(b[0])),abs(int(a[1])-int(b[1])))

def assignment(cost):
    """Rectangular Hungarian algorithm; deterministic ties, rows <= columns."""
    n,m=cost.shape
    if n==0:return []
    if n>m:raise ValueError('Assignment requires at least one option per active slot')
    u=np.zeros(n+1);v=np.zeros(m+1);p=np.zeros(m+1,dtype=int);way=np.zeros(m+1,dtype=int)
    for i in range(1,n+1):
        p[0]=i;j0=0;minv=np.full(m+1,np.inf);used=np.zeros(m+1,dtype=bool)
        while True:
            used[j0]=True;i0=p[j0];delta=np.inf;j1=0
            for j in range(1,m+1):
                if used[j]:continue
                cur=cost[i0-1,j-1]-u[i0]-v[j]
                if cur<minv[j]:minv[j]=cur;way[j]=j0
                if minv[j]<delta:delta=minv[j];j1=j
            for j in range(m+1):
                if used[j]:u[p[j]]+=delta;v[j]-=delta
                else:minv[j]-=delta
            j0=j1
            if p[j0]==0:break
        while True:
            j1=way[j0];p[j0]=p[j1];j0=j1
            if j0==0:break
    result=[-1]*n
    for j in range(1,m+1):
        if p[j]:result[p[j]-1]=j-1
    return result

def current_step_cost(env,obs,i,direction):
    """Original flight energy formula using only the UAV's currently visible wind."""
    wind=np.array([obs.local[i,1,7,7],obs.local[i,2,7,7]])
    return float(env._flight_energy(env._get_real_v(np.asarray(direction),wind),env.T))

def estimates(env,obs,ids,cfg):
    """Assumption-labeled approximate availability from current telemetry only."""
    persistence=[]
    for i in ids:
        p=obs.positions[i]; direction=(int(np.sign(obs.vehicle[0]-p[0])),int(np.sign(obs.vehicle[1]-p[1])))
        # A hovering wind estimate is only used when already at the vehicle.
        cost=max(current_step_cost(env,obs,i,direction),1.)
        safe=max(obs.return_ratio*obs.initial_energy,cheb(p,obs.vehicle)*cost*(1+obs.return_margin))
        persistence.append(float(np.clip((obs.energies[i]-safe)/(cost*cfg.horizon),0,1)))
    # FIFO is an optimistic current-queue-only estimate: no future arrivals,
    # constant charging power, ignored return-energy exhaustion and travel delays
    # beyond the current deterministic grid distance. It is not a future event.
    charge_ready={}
    for i,s in enumerate(obs.statuses):
        # The V1.5 state machine stays charging until fully charged. The .95
        # qualification applies to standby, not an early release of the slot.
        if s=='charging':charge_ready[i]=math.ceil(max(0.,(obs.initial_energy-obs.energies[i])/obs.charge_j_per_step))
        elif s=='standby' and obs.energies[i]>=obs.launch_ratio*obs.initial_energy:charge_ready[i]=0.
    busy=max((math.ceil(max(0.,(obs.initial_energy-obs.energies[i])/obs.charge_j_per_step)) for i,s in enumerate(obs.statuses) if s=='charging'),default=0.)
    for i in obs.queue:
        need=math.ceil(max(0.,(obs.initial_energy-obs.energies[i])/obs.charge_j_per_step))
        charge_ready[i]=busy+need
        busy+=need
    for i,s in enumerate(obs.statuses):
        if s=='returning':
            charge_ready[i]=busy+cheb(obs.positions[i],obs.vehicle)+math.ceil(max(0.,(obs.initial_energy-obs.energies[i])/obs.charge_j_per_step))
    ready=sum(max(0.,1-t/cfg.horizon) for t in charge_ready.values())
    return np.array(persistence),ready,charge_ready

def choose(env,obs,cnn,policy:Policy,cfg:PlannerConfig):
    ids=np.flatnonzero(obs.flight_mask).tolist();actions=[0]*len(obs.flight_mask)
    if not ids:return actions,{'targets':{},'prediction':None}
    with torch.no_grad():base=cnn(torch.as_tensor(obs.local[ids],dtype=torch.float32)).argmax(-1).tolist()
    for i,a in zip(ids,base):actions[i]=int(a)
    if policy==Policy.P0:return actions,{'targets':{},'prediction':None}
    possible=np.argwhere(np.isfinite(obs.known_uncertainty)&(obs.known_uncertainty>0))
    if not len(possible):return actions,{'targets':{},'prediction':None}
    positions=np.array([obs.positions[i] for i in ids]);d=np.max(np.abs(positions[:,None,:]-possible[None,:,:]),axis=-1)
    # One fixed candidate filter and one matching call for both P1 and P2.
    order=np.lexsort((possible[:,1],possible[:,0],d.min(0)))[:cfg.max_candidates]
    candidates=possible[order];dist=d[:,order].astype(float)
    cost=dist.copy(); cost+=np.arange(len(candidates))[None,:]*1e-6
    # Same conservative energy-to-target-and-home filter for both planners.
    for row,i in enumerate(ids):
        pos=obs.positions[i];home=obs.vehicle;direction=(int(np.sign(home[0]-pos[0])),int(np.sign(home[1]-pos[1])))
        unit=max(current_step_cost(env,obs,i,direction),1.)
        return_dist=np.max(np.abs(candidates-np.asarray(home)),axis=1)
        need=(dist[row]+return_dist*(1+obs.return_margin))*unit
        cost[row,need>obs.energies[i]]=1e6
    prediction=None
    if policy==Policy.P2:
        survival,ready,times=estimates(env,obs,ids,cfg)
        spatial=np.exp(-dist/cfg.spatial_scale)
        holes=((1-survival)[:,None]*spatial).sum(0)
        home_dist=np.max(np.abs(candidates-np.asarray(obs.vehicle)),axis=1)
        recover=ready*np.exp(-home_dist/cfg.spatial_scale)
        gap=np.maximum(0.,holes-.5*recover)
        cost-=cfg.forecast_weight*survival[:,None]*gap[None,:]
        prediction={'survival':survival.tolist(),'estimated_ready_score':ready,'estimated_ready_steps':times}
    # Dummy slots mean CNN fallback if no feasible target; budget remains fixed.
    full=np.concatenate((cost,np.full((len(ids),len(ids)),1e5)),axis=1)
    chosen=assignment(full);targets={}
    occupied={obs.positions[i] for i in ids}
    for row,(i,k) in enumerate(zip(ids,chosen)):
        if k>=len(candidates) or cost[row,k]>=1e5:continue
        target=tuple(int(x) for x in candidates[k]);targets[i]=target;p=obs.positions[i];options=[]
        for a,direction in enumerate(env.directions):
            q=(p[0]+direction[0],p[1]+direction[1])
            if not(0<=q[0]<20 and 0<=q[1]<20) or (q in occupied and q!=p):continue
            energy=current_step_cost(env,obs,i,direction)
            options.append((cheb(q,target)+cfg.energy_weight*energy/10000.,a))
        if options:actions[i]=min(options)[1]
    return actions,{'targets':targets,'prediction':prediction,'availability_features':availability_features(obs).tolist()}
