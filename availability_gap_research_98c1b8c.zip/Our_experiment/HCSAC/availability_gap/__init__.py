"""Current-observation and availability-aware rule baselines."""
