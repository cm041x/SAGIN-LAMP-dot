#!/usr/bin/env python3
"""Rebuild paired comparisons from saved, already completed rollouts."""
import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results/availability_gap'
FILES = {'fixed_haps': RESULTS / 'confirmation_fixed_haps_per_run.csv',
         'pretrained_gcn': RESULTS / 'confirmation_pretrained_gcn_per_run.csv'}
METRICS = ['coverage_auc','final_coverage','total_uav_energy_j','return_flight_energy_j',
           'repeated_visit_ratio','integrated_fleet_deficit','mean_active','mean_queue_length',
           'mean_waiting_steps_completed','rotation_window_steps','ordinary_steps',
           'rotation_window_gain_per_active_step','ordinary_gain_per_active_step',
           'planning_seconds','mean_post_charge_first_new_delay']
POLICIES = ['p0_frozen_cnn','p1_current_coordination','p2_predicted_availability']

def num(row, key):
    value = row.get(key, '')
    return None if value in ('', 'None', 'null') else float(value)

def mean(values):
    vals = [v for v in values if v is not None]
    return statistics.mean(vals) if vals else None

def write_csv(path, rows):
    with path.open('w', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def main():
    aggregates, pairs, checks = [], [], {}
    for control, path in FILES.items():
        with path.open(newline='') as fh:
            rows = list(csv.DictReader(fh))
        assert len(rows) == 36 and len({r['run_id'] for r in rows}) == 36
        assert all(int(r['exhaustion_count']) == 0 and int(r['inactive_offload_count']) == 0 and int(r['max_charging_count']) <= 1 for r in rows)
        assert all(int(r['steps']) == 500 for r in rows)
        checks[control] = {'valid_runs': len(rows), 'exhaustion': 0, 'inactive_offload': 0, 'charger_overcapacity': 0}
        for group in ['All','Low Wind','Moderate Wind','Strong Wind']:
            selected = [r for r in rows if group == 'All' or r['wind_class'] == group]
            for policy in POLICIES:
                samples = [r for r in selected if r['policy'] == policy]
                entry = {'control': control, 'wind_class': group, 'policy': policy, 'n': len(samples)}
                for metric in METRICS:
                    entry[metric + '_mean'] = mean([num(r, metric) for r in samples])
                for threshold in (90, 95):
                    met = [r for r in samples if r[f'time_to_{threshold}_observed'] == 'True']
                    entry[f'reached_{threshold}_count'] = len(met)
                    entry[f'time_to_{threshold}_mean_observed'] = mean([num(r,f'time_to_{threshold}_steps') for r in met])
                    entry[f'energy_to_{threshold}_mean_observed'] = mean([num(r,f'energy_to_{threshold}_j') for r in met])
                entry['relaunch_delay_observed_count'] = sum(int(r['post_charge_relaunch_completed_count']) for r in samples)
                entry['relaunch_delay_censored_count'] = sum(int(r['post_charge_relaunch_censored_count']) for r in samples)
                entry['runs_reaching_one'] = sum(int(r['min_active']) <= 1 for r in samples)
                aggregates.append(entry)
            for left, right in ((POLICIES[1],POLICIES[0]),(POLICIES[2],POLICIES[1])):
                indexed = {(r['wind_seed'],r['terrain_seed'],r['infra_seed'],r['policy']):r for r in selected}
                keys = sorted({(r['wind_seed'],r['terrain_seed'],r['infra_seed']) for r in selected})
                for metric in ['coverage_auc','final_coverage','repeated_visit_ratio','integrated_fleet_deficit','total_uav_energy_j']:
                    diffs = [num(indexed[(*key,left)],metric)-num(indexed[(*key,right)],metric) for key in keys]
                    pairs.append({'control':control,'wind_class':group,'comparison':left+' - '+right,'metric':metric,
                        'n_pairs':len(diffs),'mean_difference':statistics.mean(diffs),'median_difference':statistics.median(diffs),
                        'positive':sum(d>1e-12 for d in diffs),'ties':sum(abs(d)<=1e-12 for d in diffs),'negative':sum(d< -1e-12 for d in diffs)})
    write_csv(RESULTS/'aggregate_metrics.csv',aggregates)
    write_csv(RESULTS/'paired_comparisons.csv',pairs)
    (RESULTS/'audit.json').write_text(json.dumps(checks, indent=2)+'\n')
    print(json.dumps({'checks':checks, 'overall': [a for a in aggregates if a['wind_class']=='All'], 'auc_pairs':[p for p in pairs if p['wind_class']=='All' and p['metric']=='coverage_auc']},indent=2))

if __name__ == '__main__':
    main()
