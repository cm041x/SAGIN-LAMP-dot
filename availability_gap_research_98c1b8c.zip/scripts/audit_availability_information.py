"""Controlled current-state perturbations; no training or environment mutation persists."""
import json
from collections import deque
from pathlib import Path
import numpy as np
import torch
from Our_experiment.HCSAC.ENV.UAVenv_DynamicFleet import Status
from Our_experiment.HCSAC.training.dynamic_hcsac_trainer import new_env
from Our_experiment.HCSAC.lamp_method.collector import frozen_flight_actor
from Our_experiment.HCSAC.flight_residual.policy import FlightActor,flight_observe,encode
from Our_experiment.HCSAC.availability_gap.observation import observe,availability_features
from Our_experiment.HCSAC.availability_gap.planner import estimates,PlannerConfig

ROOT=Path(__file__).resolve().parents[1]
torch.set_num_threads(2);env=new_env(500,{'wind_seed':1180,'terrain_seed':900000,'infra_seed':900000});cnn=frozen_flight_actor()
u=env.uavs[4];u['status']=Status.CHARGING;u['done']=True;u['energy']=.2*env.initial_energy
before=flight_observe(env,env._get_obs(),cnn);o1=observe(env,env._get_obs())
u['energy']=.8*env.initial_energy;after=flight_observe(env,env._get_obs(),cnn);o2=observe(env,env._get_obs())
ids=np.flatnonzero(o1.flight_mask).tolist();_,ready1,_=estimates(env,o1,ids,PlannerConfig());_,ready2,_=estimates(env,o2,ids,PlannerConfig())
results={'charging_energy_perturbation':{'slot':4,'ratios':[.2,.8],
    'physical_edges_identical':bool(torch.equal(before.edge_index,after.edge_index)),
    'inactive_node_context_changed':bool(not torch.equal(before.context[4],after.context[4])),
    'availability_telemetry_max_change':float(np.max(np.abs(availability_features(o1)-availability_features(o2)))),
    'estimated_ready_score_before':ready1,'estimated_ready_score_after':ready2,'active_graph_embedding_max_delta':{}}}
for variant in ('gcn_flight_residual','lamp_plain_flight_residual'):
    torch.manual_seed(12);actor=FlightActor(variant)
    with torch.no_grad():h1,_=encode(actor.encoder,before,None);h2,_=encode(actor.encoder,after,None)
    results['charging_energy_perturbation']['active_graph_embedding_max_delta'][variant]=float((h1[:4]-h2[:4]).abs().max())
env.step_number=10;u['status']=Status.WAITING;env.queue=deque([4]);u['waiting_since_step']=8
before=flight_observe(env,env._get_obs(),cnn);o1=observe(env,env._get_obs());u['waiting_since_step']=2
after=flight_observe(env,env._get_obs(),cnn);o2=observe(env,env._get_obs())
results['waiting_age_perturbation']={'ages':[2,8],'availability_telemetry_max_change':float(np.max(np.abs(availability_features(o1)-availability_features(o2)))),
                                     'active_graph_embedding_max_delta':{}}
for variant in ('gcn_flight_residual','lamp_plain_flight_residual'):
    torch.manual_seed(12);actor=FlightActor(variant)
    with torch.no_grad():h1,_=encode(actor.encoder,before,None);h2,_=encode(actor.encoder,after,None)
    results['waiting_age_perturbation']['active_graph_embedding_max_delta'][variant]=float((h1[:4]-h2[:4]).abs().max())
assert all(v==0 for row in results.values() for v in row['active_graph_embedding_max_delta'].values())
assert results['charging_energy_perturbation']['availability_telemetry_max_change']>0
assert results['waiting_age_perturbation']['availability_telemetry_max_change']>0
out=ROOT/'results/availability_gap/sensitivity.json';out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
