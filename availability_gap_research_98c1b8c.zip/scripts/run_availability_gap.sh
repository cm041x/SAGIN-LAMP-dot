#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1 SDL_VIDEODRIVER=dummy MPLBACKEND=Agg OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
export MPLCONFIGDIR="$PWD/.mplconfig"
PY="${PYTHON_BIN:-/opt/miniconda3/envs/SAGIN/bin/python}"
"$PY" -m unittest discover -s tests -p 'test_dynamic_fleet*.py' -v
"$PY" -m unittest discover -s tests -p 'test_availability_gap.py' -v
"$PY" scripts/audit_availability_information.py
"$PY" -m Our_experiment.HCSAC.availability_gap.experiment --stage development --resume
"$PY" -m Our_experiment.HCSAC.availability_gap.experiment --stage confirmation --resume
if "$PY" - <<'PY'
import csv, statistics
with open('results/availability_gap/confirmation_fixed_haps_per_run.csv', newline='') as f:
    rows=list(csv.DictReader(f))
x={(r['wind_seed'], r['terrain_seed'], r['policy']):float(r['coverage_auc']) for r in rows}
keys={(r['wind_seed'],r['terrain_seed']) for r in rows}
d=[x[(*k,'p1_current_coordination')]-x[(*k,'p0_frozen_cnn')] for k in keys]
assert len(d)==12
raise SystemExit(0 if statistics.mean(d)>=.01 and sum(v>0 for v in d)>=8 else 1)
PY
then
  "$PY" -m Our_experiment.HCSAC.availability_gap.experiment --stage offload-validation --resume
else
  echo 'Prespecified shared-GCN follow-up criterion was not met.'
  exit 0
fi
"$PY" scripts/analyze_availability_gap.py
